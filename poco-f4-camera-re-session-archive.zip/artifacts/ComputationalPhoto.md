{
  "status": "complete",
  "doc": "docs/04-computational-photography.md (414 lines)",
  "doc_contents": [
    "17-feature catalog with stock classes, settings keys, vendor libs and decompiled file:line evidence",
    "explicit implemented vs hardware/vendor-bound split",
    "stock-to-reimpl mapping table",
    "3 mermaid diagrams (night sequence, repro pipeline, size-policy state)",
    "algorithm/complexity, memory caps, deviations, JVM and on-device verification"
  ],
  "code": {
    "package": "dev.pocof4.camera.photo",
    "public_apis": [
      "HdrFusion.fuse(List<Bitmap>): Bitmap (2..5 frames, mixed sizes, 3MP fusion cap)",
      "NightFusion.merge(List<Bitmap>): Bitmap (adaptive 30MP total budget, 6-12MP/frame)",
      "SaliencyBlur.render(Bitmap, Float): Bitmap (2MP process cap, full-res subject composite up to 12MP)"
    ],
    "pure_cores": [
      "ImageMath.kt",
      "AlignCore.kt (pyramid SAD/gradient, integer shift, 3% confidence gate)",
      "ExposureFusionCore.kt (Mertens weights + Laplacian pyramid + soft-shoulder tone curve)",
      "TemporalMergeCore.kt (alignment + median gate + shadow gamma LUT)",
      "SaliencyCore.kt (multi-scale centre-surround + local contrast, feather mask, 5-level variable blur)"
    ],
    "android_bridge": [
      "BitmapPixels.kt (HARDWARE copy, centre-crop scaling, safe recycle)"
    ]
  },
  "tests": {
    "files": [
      "AlignmentCoreTest (4)",
      "ExposureFusionCoreTest (3)",
      "TemporalMergeCoreTest (4)",
      "SaliencyCoreTest (3)"
    ],
    "coverage": [
      "injected (+5,-3), (-4,+2), flat/identical ambiguity",
      "dark/bright clipping brackets fused with texture in both halves and 0 clipped pixels",
      "5-frame variance ratio ~0.2 of single frame",
      "single-frame outlier blob rejection",
      "shadow lift 20->39",
      "3-frame translated burst restored (mean error 0)",
      "saliency inside 0.92 vs outside 0.06, peak inside subject",
      "subject energy ratio 1.0, background ratio ~0.00003"
    ]
  },
  "validation": "No gradle/build/test run performed per instructions. Thresholds were validated by standalone Python re-implementations of the exact Kotlin math: alignment returned (5,-3), (-4,2), (0,0), (0,0); fusion left std 5.9 / right std 16.4, mean 159.8, 0 clip; merge variance ratio 0.20, gamma 39; saliency map 0.915 vs 0.058, mask 1.0 vs 0.0, subject/background energy 1.0/0.00003.",
  "main_agent_checks": [
    "Run ./gradlew :app:testDebugUnitTest for the four photo test classes",
    "Run a full assembleDebug to confirm no unresolved references",
    "Compile-time note: ImageMath is public so JVM tests can access it; BitmapPixels stays internal"
  ],
  "risks": [
    "Alignment uses stride sampling on very large frames (>=96x96 grid); textured scenes tested at full sampling",
    "ExposureFusionCore is capped at 3MP for heap reasons (~150MB peak) and upscales result",
    "Saliency bokeh is a progressive box-blur approximation, not a true disc aperture (documented)"
  ]
}