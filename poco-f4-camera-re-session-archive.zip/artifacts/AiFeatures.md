{
  "status": "complete",
  "deliverables": {
    "doc": "docs/03-ai-features.md",
    "main": [
      "reimpl/app/src/main/java/dev/pocof4/camera/ai/AiSceneAnalyzer.kt",
      "reimpl/app/src/main/java/dev/pocof4/camera/ai/AiBeauty.kt",
      "reimpl/app/src/main/java/dev/pocof4/camera/ai/WatermarkRenderer.kt",
      "reimpl/app/src/main/java/dev/pocof4/camera/ai/SceneClassifier.kt",
      "reimpl/app/src/main/java/dev/pocof4/camera/ai/SceneDebouncer.kt",
      "reimpl/app/src/main/java/dev/pocof4/camera/ai/SceneLabels.kt",
      "reimpl/app/src/main/java/dev/pocof4/camera/ai/LumaStats.kt",
      "reimpl/app/src/main/java/dev/pocof4/camera/ai/SkinMask.kt",
      "reimpl/app/src/main/java/dev/pocof4/camera/ai/BeautyProcessor.kt",
      "reimpl/app/src/main/java/dev/pocof4/camera/ai/BoxBlur.kt"
    ],
    "tests": [
      "reimpl/app/src/test/java/dev/pocof4/camera/ai/SceneClassifierTest.kt",
      "reimpl/app/src/test/java/dev/pocof4/camera/ai/SceneDebouncerTest.kt",
      "reimpl/app/src/test/java/dev/pocof4/camera/ai/LumaStatsTest.kt",
      "reimpl/app/src/test/java/dev/pocof4/camera/ai/SkinMaskTest.kt",
      "reimpl/app/src/test/java/dev/pocof4/camera/ai/BoxBlurTest.kt",
      "reimpl/app/src/test/java/dev/pocof4/camera/ai/BeautyProcessorTest.kt"
    ]
  },
  "public_apis": {
    "AiSceneAnalyzer": "class AiSceneAnalyzer(context: Context, frameSource: FrameSource, onScene: (AiScene) -> Unit) : FrameListener, Feature; public @Volatile var isFrontCamera; rate 400 ms, ML Kit labeler threshold 0.4, face min 0.05, detectors closed on stop()",
    "AiBeauty": "object AiBeauty { fun apply(bitmap: Bitmap, strength: Float): Bitmap } — blocking ML Kit face detection, soft YCbCr+ellipse mask, box-blur guided smoothing with edge stop, brightening, strength clamped, zero faces returns copy",
    "WatermarkRenderer": "object WatermarkRenderer { fun render(bitmap: Bitmap, scene: AiScene?, timestampMs: Long): Bitmap } — bottom-left AI SCENE badge (known scenes), yyyy.MM.dd HH:mm, POCO F4, width-scaled, shadowed white text",
    "pure": [
      "SceneClassifier/SceneInput/SceneVerdict/LabelScore",
      "SceneDebouncer",
      "SceneLabels",
      "LumaStats",
      "SkinMask/FaceOval",
      "BeautyProcessor",
      "BoxBlur"
    ]
  },
  "behaviour": {
    "classifier": "24-step documented priority table: moon, candle-night, ID card, PPT, DOC, curry, food, sunset, night-luma, snow, sea, beach, sky, cloud, overcast, plants, animals, architecture/vehicles, human (face width >= 7.5%, suppressed on front camera), unknown. Backlight (top/bottom ratio >= 2.2) never emits reserved ids 23/24.",
    "debounce": "2 consecutive analyses and >= 300 ms before publishing; repeats suppressed; leaving ID_CARD requires > 3000 ms (stock semantics); UNKNOWN debounced like any id."
  },
  "evidence_cited": [
    "AiSceneModeConstant.java (ids, isPopTipRequired)",
    "AiSceneMultipleASD.java:35-56,57-76,119-162 (20-frame filter, 300 px face rule, 300 ms/3 s throttles, moon/front handling)",
    "CaptureResultVendorTags.java:398",
    "AiSceneManager.java:60+,245-256",
    "AiSceneModeConstant/strings.xml/arrays.xml id+label drift (40 constants in 46-slot space; 23/24 reserved)",
    "ASDEngine.java:9-38 and ASDHandler.java:36-98",
    "CameraSettings.java:99,141-148,261-262,395,602-607,272",
    "BeautyConstant.java:59,144-182; ShaderNativeUtil.java:12"
  ],
  "notes": [
    "No build/test/gradle run performed, per project rules; JVM tests are pure Kotlin (no android.* imports).",
    "AiSceneAnalyzer.isFrontCamera is a host-settable flag; CameraEngine currently binds only the back camera.",
    "Classifier uses the shared PreviewFrame.toBitmap() from camera/FrameBitmap.kt with default rotation (upright) and passes rotation 0 to InputImage to avoid double rotation."
  ]
}