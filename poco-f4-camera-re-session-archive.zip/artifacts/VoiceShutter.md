{
  "summary": "Implemented the voice shutter feature: docs, SpeechRecognizer-based controller, pure-Kotlin matcher, JVM tests.",
  "files_created": [
    "docs/02-voice-shutter.md",
    "reimpl/app/src/main/java/dev/pocof4/camera/voice/VoiceShutterController.kt",
    "reimpl/app/src/main/java/dev/pocof4/camera/voice/VoiceKeywordMatcher.kt",
    "reimpl/app/src/test/java/dev/pocof4/camera/voice/VoiceKeywordMatcherTest.kt"
  ],
  "api": {
    "VoiceShutterController": "class VoiceShutterController(context: Context, onKeyword: (String) -> Unit) : Feature, name=\"voice-shutter\"; extra read-only isInert/isRunning; start/stop marshal to main looper; onKeyword on main thread",
    "VoiceKeywordMatcher": "pure Kotlin, no android imports; language-aware phrase sets (zh vs en), normalization, Latin word-boundary matching, CJK substring matching, 2500 ms debounce + one-trigger-per-utterance state, match/accept/beginUtterance/reset; injectable clock"
  },
  "behavior": [
    "SpeechRecognizer created on main thread with EXTRA_PREFER_OFFLINE, partial results, locale language tag.",
    "Restart on onResults/onError: 300 ms base, exponential backoff capped 3 s, recognizer recreated after 3 consecutive errors; no-match/speech-timeout reset backoff.",
    "Missing RECORD_AUDIO or no recognition service => inert (isInert=true), no crash; SecurityException at startListening also marks inert.",
    "stop() cancels pending restart, resets matcher, cancel/destroy on main thread, avoids destroying a superseding restarted recognizer.",
    "Stock evidence cited with file:line in doc: SpeechShutterImpl, MultiWakeupEngineImpl (640 frame, handler msgs 1/2/3/5/6, CircleBuffer 1920000, wakeup==2 broadcast), VoiceRecord 16 kHz mono PCM16 320-byte reads, JNI, Camera2Module 3457 -> trigger 110, localized strings, manifest alias/settings keys."
  ],
  "tests": [
    "Reimpl/app/src/test/.../VoiceKeywordMatcherTest.kt: 19 JUnit tests covering exact/case/punctuation/NBSP/trailing words/longest phrase, cheesecake/photograph/captured negatives, partial words, empty/null, Chinese substring + fullwidth punctuation, cross-language rejection, debounce boundary, one-per-utterance, beginUtterance, reset, non-match not consuming state."
  ],
  "blocker_reported_to_main": "reimpl/app/src/main/AndroidManifest.xml needs <queries><intent><action android:name=\"android.speech.RecognitionService\"/></intent></queries> for targetSdk 34 package visibility (SpeechRecognizer requirement). I could not edit the manifest per ownership rules; reported to Main and documented in docs/02-voice-shutter.md.",
  "checks_for_main": [
    "Run the single Gradle build and JVM tests: ./gradlew :app:testDebugUnitTest --tests 'dev.pocof4.camera.voice.*'",
    "Add the manifest <queries> entry reported above.",
    "On-device: enable voice shutter, test cheese/拍照, verify cheesecake does not trigger, debounce within 2.5 s, and microphone released after disable."
  ]
}