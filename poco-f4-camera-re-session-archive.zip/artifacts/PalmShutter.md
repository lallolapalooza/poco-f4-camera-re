{
  "status": "complete",
  "deliverables": [
    "docs/01-palm-gesture-shutter.md",
    "reimpl/app/src/main/java/dev/pocof4/camera/gesture/PalmGestureDetector.kt",
    "reimpl/app/src/main/java/dev/pocof4/camera/gesture/PalmHoldStateMachine.kt",
    "reimpl/app/src/main/java/dev/pocof4/camera/gesture/PalmPoseHeuristics.kt",
    "reimpl/app/src/test/java/dev/pocof4/camera/gesture/PalmHoldStateMachineTest.kt",
    "reimpl/app/src/test/java/dev/pocof4/camera/gesture/PalmPoseHeuristicsTest.kt"
  ],
  "public_api": "class PalmGestureDetector(context: Context, frameSource: FrameSource, onTrigger: () -> Unit) : FrameListener, Feature, with companion MODEL_ASSET and volatile stats: PalmGestureStats (active, recognizerReady, lastGesture, lastScore, lastEvent, triggers, lastTriggerTimestampNs, lastError).",
  "design": {
    "detection": "MediaPipe GestureRecognizer (tasks-vision 0.10.14, IMAGE mode, 1 hand, confidences 0.5) on assets/gesture_recognizer.task; Open_Palm accepted only when score >= 0.6 in the pure state machine and the pure landmark extension gate passes.",
    "timing": "PalmHoldStateMachine: 600 ms hold, 3.0 s cooldown (48 x 62 ms stock interval), 500 ms max palm gap, all measured from PreviewFrame.timestampNs; stale/duplicate timestamps are ignored; non-palm or low-confidence frames reset the hold; refire requires cooldown expiry plus a fresh hold.",
    "threading": "onFrame does CAS + executor.execute only; a private single-thread daemon 'palm-gesture' serialises create/recognize/release and drops frames while one inference is in flight, so the CameraEngine analysis thread never runs inference.",
    "orientation": "frame.toBitmap(applyRotation=false) + ImageProcessingOptions.setRotationDegrees(frame.rotationDegrees).",
    "failure": "recognizer creation/inference exceptions are logged into stats.lastError; recognizerUnavailable prevents per-frame retry; stop() posts GestureRecognizer.close() behind in-flight work; onTrigger exceptions are swallowed."
  },
  "evidence_cited": [
    "HandGestureDecoder.java 34-42,135-153,166-167,179-201,205-247",
    "HandGesture.java 9-25",
    "TriggerConstant.java:15",
    "ImageActionImpl.java:187,212,231,243",
    "TimerBurstManager.java:171-203,259-322",
    "CameraSettings.java:285-286,805-807,2461-2466,3484-3487",
    "DataItemRunning.java:42-43,526-527,667-674,723-724,765-766",
    "ComponentRunningTimer.java:40-55",
    "ExtraTopConfigUtils.java:34-39",
    "strings.xml 1153-1154, values-zh-rCN 868-869",
    "native libhandengine.arcsoft.so ARC_HE_Init/Process/Uninit"
  ],
  "tests": "PalmHoldStateMachineTest covers single-frame no-fire, sustained fire-once at 620 ms, exact hold boundary, cooldown refire suppression + fresh hold, non-palm reset, long-gap restart and boundary, all non-palm gestures, low confidence, duplicate/backwards timestamps, reset, custom windows. PalmPoseHeuristicsTest covers open/fist/2-of-4/3-of-4/narrow/malformed landmarks. State-machine expectations were re-simulated independently and match.",
  "not_run": "No gradle/build/test run per instructions; coordinator runs the single build. All files are inside the assigned gesture package, docs/ and test tree; no shared files were modified."
}